ArcMap Raster Editor

[Description]
ArcMap Raster Editor is an AddIn for ArcMap 10.0 and above. It is especially used for manual editing of raster layer, which is not available for ArcMap.

[Install]
1. Double click the RasterEditor.esriAddIn and press the Install Add-In button 
at bottom of wizzard.
2. If success, you can find the Raster Editor at the ArcMap Add-In Manager 
(Main Menu -> Customize -> Add-In Manager).
3. Right click on toolbar and add the Raster Editor toolbar in the ArcMap.

[Uninstall]
The add-in can be simply deleted at the Add-In Manager of ArcMap.

[User Guide]
For detailed guide of the tool, please visit https://github.com/dz316424/arcmap-raster-editor/wiki

If you have any question or suggestion, wirte it at 
https://github.com/dz316424/arcmap-raster-editor
or send me an email to 
jkon@foxmail.com

Have fun :)

Haoliang Yu